/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtp;


public class Calculadora {
  
    private Integer num1;
    private Integer num2;
    
   
    public Integer soma(){
        return this.num1 + this.num2;     
    }
        public Integer sub(){
        return this.num1 - this.num2;     
    }
        public Integer mult(){
        return this.num1 * this.num2;     
    }
        public Integer div(){
        return this.num1 / this.num2;     
    }    

    void setnum1(Integer n1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setnum2(Integer n2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    
   