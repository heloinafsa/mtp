/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtp;

import java.util.Scanner;

/**
 *
 * @author ifg
 */
public class MainCalc {
       
    public static void main(String[] args) {
    
    Scanner in = new Scanner(System.in);
    
    Integer n1 = 0;
    Integer n2 = 0;
    String op = "";
    
    System.out.println("Digite o primeiro valor");
	n1 = in.nextInt();
    
    System.out.println("Digite o segunto valor");
	n2 = in.nextInt(); 
        
    System.out.println("Digite a operação que deseja realisar (+, -, *, /)");
	op = in.next();
        
        
     Calculadora calc = new Calculadora();
        calc.setnum1(n1);
	calc.setnum2(n2);
    
    System.out.println("Resulta da operação = ");
        
    switch (op) {
	case "+":

            System.out.println(calc.soma());
		break;

	case "-":
	System.out.println(calc.sub());
	break;

	case "*":
            System.out.println(calc.mult());
            break;

	case "/":
            System.out.println(calc.div());
            break;
		}
            
            
    }
    
}
